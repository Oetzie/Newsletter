----------------------
Newsletter
----------------------
Version: 1.1.0
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

Newsletter gives you a user-friendly interface for managing your
newsletter and subscriptions.