----------------------
Newsletter
----------------------
Version: 1.2.0
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

Newsletter gives you a user-friendly interface for managing your
newsletter subscriptions and send resources to the subscriptions as
a newsletter.

- Form Addon (by Oene Tjeerd de Bruin) required for the (un)subscribe forms.