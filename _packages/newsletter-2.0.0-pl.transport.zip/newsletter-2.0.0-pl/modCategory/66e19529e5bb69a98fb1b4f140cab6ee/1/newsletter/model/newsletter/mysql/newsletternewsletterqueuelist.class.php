<?php

/**
 * Newsletter
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/newsletternewsletterqueuelist.class.php';

class NewsletterNewsletterQueueList_mysql extends NewsletterNewsletterQueueList
{
}
