<?php

/**
 * Newsletter
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/newsletterlist.class.php';

class NewsletterList_mysql extends NewsletterList
{
}
